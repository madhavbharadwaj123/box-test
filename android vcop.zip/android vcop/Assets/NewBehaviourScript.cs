﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {
  public GameObject go;
    public static int score;
    int rangex = 10;
    int rangey = 10;
    int rangez = 10;
    float starttime;
    float timer;
    // Use this for initialization
    void Start()
    {
        timer = 0;
        score = 0;
        starttime = Time.time;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        timer = Time.time - starttime;
        if (timer % 2 == 0) { 
        GameObject gb = Instantiate(go) as GameObject;
        rangex = Random.Range(-20, 20);
        rangey = Random.Range(3, 30);
        rangez = Random.Range(-20, 10);
        gb.transform.position = Camera.main.transform.position + new Vector3(rangex, rangey, rangez);
    }
    }
   
}
