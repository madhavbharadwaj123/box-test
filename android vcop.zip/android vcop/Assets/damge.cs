﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damge : MonoBehaviour {
    public static int i;
    Ray ray;
    RaycastHit hit;
    float score;
	// Use this for initialization
	void Start () {
        i = 0;
        score = 0;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButton(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 100f))
            {
                i = 1;
                if(hit.transform.tag == "enemy")
                Destroy(hit.transform.gameObject);
                score++;
            }
        }
	}
    private void OnGUI()
    {
        GUI.Box(new Rect(Screen.width / 2 - 50, 40, 100, 40),"" + score);
    }
}
