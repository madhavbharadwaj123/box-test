﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroyscr : MonoBehaviour {
    int y;
    Vector3 pos;
    Rigidbody rbd;
	// Use this for initialization
	void Start () {
        rbd = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        pos = transform.position;
        if (pos.y < 0.1)
            Destroy(gameObject);    
	}
}
